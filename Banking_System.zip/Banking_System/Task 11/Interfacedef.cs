﻿using Banking_System.classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_System.interfacedef
{
    interface ICustomerServiceProvider
    {
        long get_account_balance(long account_number);
        long deposit(long account_number, float amount);

      float  withdraw(long account_number, float amount);

        void transfer(long from_account_number, int to_account_number, float amount);

        void getAccountDetails(long account_number);

    }

    interface IBankServiceProvider
    {
        Account create_account(Customer customer, long accNo, String accType, float balance);
        void listAccounts();

        void calculateInterest();
    }
    internal class Interfacedef
    {
    }
}
