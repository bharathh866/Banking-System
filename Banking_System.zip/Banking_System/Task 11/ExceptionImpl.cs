﻿using System;
using System.Collections.Generic;


namespace Banking_System.exceptionimpl
{

    public class InsufficientFundException:Exception
    {
        public InsufficientFundException(string message):base(message) { }
    }

    public class InvalidAccountException:Exception
    {
        public InvalidAccountException(string message):base(message) { }
    }

    public class OverDraftLimitExceededException:Exception
    {
        public OverDraftLimitExceededException(string message):base(message) { }
    }
    internal class ExceptionImpl
    {
    }
}
