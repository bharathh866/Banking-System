﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Banking_System.classes
//{
//    public class Customer
//    {
//        public int CustomerID;
//        public string FirstName;
//        public string LastName;
//        public string EmailAddress;
//        public string PhoneNumber;
//        public string Address;
//        public Customer()
//        {
//            Console.WriteLine("Customer default customer invoked");
//        }
//        public Customer(int customerID, string firstName, string lastName, string emailAddress, string phoneNumber, string address)
//        {
//            CustomerID = customerID;
//            FirstName = firstName;
//            LastName = lastName;
//            EmailAddress = emailAddress;
//            PhoneNumber = phoneNumber;
//            Address = address;
//        }
//        //public void SetCustomerID(int id)
//        //{
//        //    CustomerID = id;
//        //}
//        //public void SetFirstName(string firstName)
//        //{
//        //    FirstName = firstName;
//        //}
//        //public void SetLastName(string lastName)
//        //{
//        //    LastName = lastName;
//        //}
//        //public void SetemailAddress(string emailaddress)
//        //{
//        //    EmailAddress = emailaddress;
//        //}
//        //public void SetPhonenumber(string phonenumber)
//        //{
//        //    PhoneNumber = phonenumber;
//        //}
//        //public void SetAddress(string address)
//        //{
//        //    Address = address;
//        //}
//        //public int GetCustomerID()
//        //{
//        //    return CustomerID;
//        //}
//        //public string GetFirstName()
//        //{
//        //    return FirstName;
//        //}
//        //public string GetLastName()
//        //{
//        //    return LastName;
//        //}
//        //public string GetemailAddress()
//        //{
//        //    return EmailAddress;
//        //}
//        //public string GetPhonenumber()
//        //{
//        //    return PhoneNumber;
//        //}
//        //public string GetAddress()
//        //{
//        //    return Address;
//        //}
//        public void DisplayCustomerInfo()
//        {
//            Console.WriteLine("Customer ID: " + CustomerID);
//            Console.WriteLine("Customer Name: " + FirstName);
//            Console.WriteLine("Customer Email: " + LastName);
//            Console.WriteLine("Email:" + EmailAddress);
//            Console.WriteLine("phone number:" + PhoneNumber);
//            Console.WriteLine("Address:" + Address);

//        }
//    }
//    public class Account
//    {
//        public static long AccountNumber = 800;
//        public string AccountType;
//        public float AccountBalance;
//        public Customer Customer;
//        public Account()
//        {
//            AccountNumber++;
//        }
//        public Account(string accounttype, float accountbalance, Customer customer)
//        {
//            AccountNumber++;
//            AccountType = accounttype;
//            AccountBalance = accountbalance;
//            this.Customer = customer;
//        }
//        public void SetCustomer(Customer customer)
//        {
//            Customer = customer;
//        }

//        public Customer GetCustomer()
//        {
//            return Customer;
//        }
//    }
//    public class SavingsAccount : Account
//    {

//        public SavingsAccount(float balance, Customer customer) : base("savings", balance, customer)
//        {

//        }

//    }
//    public class CurrentAccount : Account
//    {
//        float overdraftLimit = 2000;
//        public CurrentAccount(float balance, Customer customer) : base("Current", balance, customer)
//        {

//        }
//    }
//    public class ZeroBalanceAccount : Account
//    {
//        public int AccountBalance = 0;
//    }
//    internal class ClassImpl

//    {


//    }
//}
