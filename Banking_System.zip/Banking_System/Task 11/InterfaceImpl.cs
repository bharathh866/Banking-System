﻿using Banking_System.classes;
using Banking_System.interfacedef;
using System;
using System.Collections.Generic;
using Banking_System.exceptionimpl;
using Banking_System.classImplement;

namespace Banking_System.interfaceimpl


{

    public class CustomerServiceProviderImpl : ICustomerServiceProvider
    {
        protected List<Account> accountList = new List<Account>();

        
        public void AddAccount(Account acc)
        {
            accountList.Add(acc);
        }


        public Account findAccount(long accountNumber)
        {
            foreach (Account acc in accountList)
            {
                if (acc != null && Account.AccountNumber == accountNumber)
                {
                    return acc;
                }
            }
            throw new InvalidAccountException($"{accountNumber} not found");
        }

        public long get_account_balance(long account_number)
        {
            Account acc = findAccount(account_number);
            if (acc != null)
                return (long)acc.AccountBalance;

            Console.WriteLine("Account not found.");
            return -1;
        }

        public long deposit(long account_number, float amount)
        {
            Account acc = findAccount(account_number);
            if (acc != null)
            {
                acc.AccountBalance += amount;
                Console.WriteLine($"Deposit successful. New balance: {acc.AccountBalance}");
                return (long)acc.AccountBalance;
            }

            Console.WriteLine("Account not found.");
            return -1;
        }

        public float withdraw(long account_number, float amount)
        {
            Account acc = findAccount(account_number);
            if (acc == null)
            {
                Console.WriteLine("Account not found.");
                throw new InvalidAccountException("Account not found");
              
            }

            if (acc is SavingsAccount )
            {
                if (acc.AccountBalance - amount < 500)
                {
                    Console.WriteLine("Minimum balance error.");
                    throw new InsufficientFundException("Balance is insufficient");
                  
                }
            }
            else if (acc is CurrentAccount )
            {
                float maxoverdraft = -7000;
                if (amount > maxoverdraft)
                {
                    Console.WriteLine("Overdraft limit exceeded.");
                    throw new OverDraftLimitExceededException("Draft limit excedded");
                  
                }
            }

            float bal=acc.AccountBalance -= amount;
            Console.WriteLine($"Withdraw successful.balance: {acc.AccountBalance}");
            return bal;
        }

        public void transfer(long from_account_number, int to_account_number, float amount)
        {
            Account from = findAccount(from_account_number);
            Account to = findAccount(to_account_number);


            float result = withdraw(from_account_number, amount);
            if (result != -1)
            {
                deposit(to_account_number, amount);
                Console.WriteLine("Transfer successful.");
            }
            else
            {
                Console.WriteLine("Transfer failed.");
            }
        }

        public void getAccountDetails(long account_number)
        {
            Account acc = findAccount(account_number);
            if (acc != null)
            {
                Console.WriteLine(" Account Details ");
                Console.WriteLine($"Account No:{Account.AccountNumber}");
                Console.WriteLine($"Type      :{acc.AccountType}");
                Console.WriteLine($"Balance   :{acc.AccountBalance}");
                Console.WriteLine(" Customer Info");
                Console.WriteLine($"Name      :{acc.Customer.FirstName} {acc.Customer.LastName}");
                Console.WriteLine($"Email     :{acc.Customer.EmailAddress}");
                Console.WriteLine($"Phone     :{acc.Customer.PhoneNumber}");
                Console.WriteLine($"Address   : {acc.Customer.Address}");
            }
            else
            {
                Console.WriteLine("Account not found.");
            }
        }
    }


    class BankServiceProviderImpl : CustomerServiceProviderImpl, IBankServiceProvider
    {
        List<Account> accountList = new List<Account>();
        string branchName;
        string branchAddress;
        Account acc = null;

        public Account create_account(Customer customer, long accNo, String accType, float balance)
        {
            if (accType == "savings")
            {
                acc = new SavingsAccount(45000, customer);

            }

            else if (accType == "Current")
            {
                acc = new CurrentAccount(85000, customer);

            }
            else
            {
                acc=new ZeroBalanceAccount(0,customer);
            }
            accountList.Add(acc);
           
            return acc;
        }
             public void listAccounts()
            {
                Console.WriteLine("----- List of Accounts -----");
                foreach (var acc in accountList)
                {
                    if (acc != null)
                    {
                        Console.WriteLine($"Account No: {Account.AccountNumber}");
                        Console.WriteLine($"Type: {acc.AccountType}");
                        Console.WriteLine($"Balance: {acc.AccountBalance}");
                        Console.WriteLine($"Customer Name: {acc.Customer.FirstName} {acc.Customer.LastName}");

                    }
                }
               
            }
       public  void calculateInterest()
        {
            float rate = 0.04f;

            Console.WriteLine("----- Calculating Interest for Savings Accounts -----");

            foreach (var acc in accountList)
            {
                if (acc is SavingsAccount)
                {
                    float interest = acc.AccountBalance * rate;
                    acc.AccountBalance += interest;

                    Console.WriteLine($"Account {Account.AccountNumber}: Interest {interest} added. New Balance = {acc.AccountBalance}");
                }
            }
        }
        
        }
        internal class InterfaceImpl
        {
        }
    }
