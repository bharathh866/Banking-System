﻿using System;
using System.Collections.Generic;
using System.Linq;

using Banking_System.interfacedef;
namespace Banking_System
{
   
   
    using Banking_System.interfaceimpl;



    class BankApp
    {
        static void Main(string[] args)
        {

            while (true) {
                Console.WriteLine("Enter " +
               "1. Create Account" +
               " 2.Withdraw" +
               "3.Deposit" +
               "4. get_balance" +
               "5.transfer" +
               "6.getAccountDetails" +
               "7.ListAccounts" +
               "8.Exit");
                int acc = int.Parse(Console.ReadLine());
         
                BankServiceProviderImpl bk = new BankServiceProviderImpl();

                switch (acc) {
                    case 1:
                        Console.WriteLine("Enter the account type_ ");
                        Console.WriteLine("1. Savings Account");
                        Console.WriteLine("2. Current Account");
                        int accountType = Convert.ToInt32(Console.ReadLine());

                        
                    
                        if (accountType == 1)
                        {
                            Console.WriteLine("Enter customer ID");
                            int custid = int.Parse(Console.ReadLine());

                            Console.WriteLine("Enter first Name");
                            string firstname = Console.ReadLine();

                            Console.WriteLine("Enter Last Name");
                            string lastname = Console.ReadLine();

                            Console.WriteLine("Enter Email Address");
                            string emailaddress = Console.ReadLine();

                            Console.WriteLine("Enter phone number");
                            string phnumber = Console.ReadLine();

                            Console.WriteLine("Enter address:");
                            string address = Console.ReadLine();

                            Customer customer = new Customer(custid, firstname, lastname, emailaddress, phnumber, address);
                            float balance = 500;
                            Account acc1 = bk.create_account(customer, 0, "Savings", balance);
                            Console.WriteLine(acc1);
                        }
                        else if (accountType == 2)
                        {
                    
                            Console.WriteLine("Enter customer ID");
                            int custid = int.Parse(Console.ReadLine());

                            Console.WriteLine("Enter first Name");
                            string firstname = Console.ReadLine();

                            Console.WriteLine("Enter Last Name");
                            string lastname = Console.ReadLine();

                            Console.WriteLine("Enter Email Address");
                            string emailaddress = Console.ReadLine();

                            Console.WriteLine("Enter phone number");
                            string phnumber = Console.ReadLine();

                            Console.WriteLine("Enter address:");
                            string address = Console.ReadLine();

                            Console.WriteLine("Enter Balance");
                            float balance = int.Parse(Console.ReadLine());

                            Customer customer = new Customer(custid, firstname, lastname, emailaddress, phnumber, address);
                            bk.create_account(customer, 0, "current", balance);
                        }
                        else
                        {

                            Console.WriteLine("Enter customer ID");
                            int custid = int.Parse(Console.ReadLine());

                            Console.WriteLine("Enter first Name");
                            string firstname = Console.ReadLine();

                            Console.WriteLine("Enter Last Name");
                            string lastname = Console.ReadLine();

                            Console.WriteLine("Enter Email Address");
                            string emailaddress = Console.ReadLine();

                            Console.WriteLine("Enter phone number");
                            string phnumber = Console.ReadLine();

                            Console.WriteLine("Enter address:");
                            string address = Console.ReadLine();

                            Console.WriteLine("Enter Balance");
                            float balance = int.Parse(Console.ReadLine());

                            Customer customer = new Customer(custid, firstname, lastname, emailaddress, phnumber, address);
                            bk.create_account(customer, 0, "zero", balance);
                        }
                        break;
                    case 2: 
                        Console.WriteLine("Enter account number:");
                        long withdrawAcc = long.Parse(Console.ReadLine());
                        Console.WriteLine("Enter amount to withdraw:");
                        float withdrawAmt = float.Parse(Console.ReadLine());
                        bk.withdraw(withdrawAcc, withdrawAmt);
                    
                        break;

                    case 3: 
                        Console.WriteLine("Enter account number:");
                        long depositAcc = long.Parse(Console.ReadLine());
                        Console.WriteLine("Enter amount to deposit:");
                        float depositAmt = float.Parse(Console.ReadLine());

                        float newBalance = bk.deposit(depositAcc, depositAmt);
                        Console.WriteLine($"Deposited successfully. New balance: {newBalance}");
                        break;

                    case 4: 
                        Console.WriteLine("Enter account number:");
                        long balAcc = long.Parse(Console.ReadLine());
                        long balanceAmt = bk.get_account_balance(balAcc);
                        Console.WriteLine($"Current balance: {balanceAmt}");
                        break;




                    default:
                        Console.WriteLine("Invalid Operation");
                        break;
                }

                Console.ReadLine();

                  
                }
            }
        }
    }