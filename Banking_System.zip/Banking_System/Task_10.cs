﻿using Banking_System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Banking_System
{

    public class Customer
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        private string emailAddress;
        public string EmailAddress
        {
            get => emailAddress;
            set { }
           
        }

        private string phoneNumber;
        public string PhoneNumber
        {
            get => phoneNumber;
            set
            {
                if (Regex.IsMatch(value, @"^\d{10}$"))
                    phoneNumber = value;
                else
                    throw new ArgumentException("Phone number must be 10 digits.");
            }
        }

        public string Address { get; set; }

        public Customer() { }

        public Customer(int customerID, string firstName, string lastName, string emailAddress, string phoneNumber, string address)
        {
            CustomerID = customerID;
            FirstName = firstName;
            LastName = lastName;
            EmailAddress = emailAddress;
            PhoneNumber = phoneNumber;
            Address = address;
        }

        public void Customerdetails()
        {
            Console.WriteLine($"ID: {CustomerID}, Name: {FirstName} {LastName}, Email: {EmailAddress}, Phone: {PhoneNumber}, Address: {Address}");
        }
    }
    public class Account
    {
        private static long accountNumber = 1000;

        public long AccountNumber { get; }
        public string AccountType { get; set; }
        public float AccountBalance { get; set; }
        public Customer Customer { get; set; }

        public Account()
        {
            AccountNumber = ++accountNumber;
        }

        public Account(string type, float balance, Customer customer) : this()
        {
            AccountType = type;
            AccountBalance = balance;
            Customer = customer;
        }

        public void PrintAccountInfo()
        {
            Console.WriteLine($"Account No: {AccountNumber}, Type: {AccountType}, Balance: {AccountBalance}");
            Customer.Customerdetails();
        }
    }


public class Bank
    {
        private List<Account> accounts = new List<Account>();

        public Account CreateAccount(Customer customer, string accType, float balance)
        {
            Account newAccount = new Account(accType, balance, customer);
            accounts.Add(newAccount);
            return newAccount;
        }

        public float GetAccountBalance(long accountNumber)
        {
            Account acc = FindAccount(accountNumber);
            return acc.AccountBalance;
        }

        public float Deposit(long accountNumber, float amount)
        {
            Account acc = FindAccount(accountNumber);
            if (acc != null)
            {
                acc.AccountBalance += amount;
                return acc.AccountBalance;
            }
            return -1;
        }

        public float Withdraw(long accountNumber, float amount)
        {
            Account acc = FindAccount(accountNumber);
            if (acc != null && acc.AccountBalance >= amount)
            {
                acc.AccountBalance -= amount;
                return acc.AccountBalance;
            }
            return -1;
        }

        public void Transfer(long fromAccNo, long toAccNo, float amount)
        {
            Account from = FindAccount(fromAccNo);
            Account to = FindAccount(toAccNo);

            if (from == null || to == null)
            {
                Console.WriteLine("One or both accounts not found.");
                return;
            }

            if (from.AccountBalance >= amount)
            {
                from.AccountBalance -= amount;
                to.AccountBalance += amount;
                Console.WriteLine("Transfer successful.");
            }
            else
            {
                Console.WriteLine("Insufficient funds.");
            }
        }

        public void GetAccountDetails(long accountNumber)
        {
            Account acc = FindAccount(accountNumber);
            if (acc != null)
            {
                acc.PrintAccountInfo();
            }
            else
            {
                Console.WriteLine("Account not found.");
            }
        }

        private Account FindAccount(long accNo)
        {
            return accounts.FirstOrDefault(a => a.AccountNumber == accNo);
        }
    }

    internal class Task_10
    {
        static void Main(String[] args) {
            Bank bank = new Bank();

            while (true)
            {
                Console.WriteLine("Select Operation:");
                Console.WriteLine("1.create Account");
                Console.WriteLine("2.deposit");
                Console.WriteLine("3.withdraw");
                Console.WriteLine("4.get Balance");
                Console.WriteLine("5.transfer");
                Console.WriteLine("6.get Account Details");
                Console.WriteLine("7.exit");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Choose account type: 1. Savings 2. Current");
                        string type = Console.ReadLine() == "1" ? "Savings" : "Current";

                        Console.WriteLine("Enter Customer ID:");
                        int id = int.Parse(Console.ReadLine());

                        Console.WriteLine("Enter Firstname:");
                        string fname = Console.ReadLine();

                        Console.WriteLine("Enter Lastname:");
                        string lname = Console.ReadLine();

                        Console.WriteLine("Enter Email:");
                        string email = Console.ReadLine();

                        Console.WriteLine("Enter Phone:");
                        string phone = Console.ReadLine();

                        Console.WriteLine("Enter Address:");
                        string address = Console.ReadLine();

                        Console.WriteLine("Enter Initial Balance:");
                        float bal = float.Parse(Console.ReadLine());

                        try
                        {
                            Customer cust = new Customer(id, fname, lname, email, phone, address);
                            Account acc = bank.CreateAccount(cust, type, bal);
                            Console.WriteLine($"Account created. Account Number: {acc.AccountNumber}");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error: {ex.Message}");
                        }

                        break;

                    case 2:
                        Console.WriteLine("Enter Account Number:");
                        long dAcc = long.Parse(Console.ReadLine());

                        Console.WriteLine("Enter Amount to Deposit:");
                        float dAmt = float.Parse(Console.ReadLine());

                        float newBal = bank.Deposit(dAcc, dAmt);
                   
                        if (newBal == 1)
                        {
                            Console.WriteLine($"New Balance: {newBal}");
                        }
                        else
                        {
                            Console.WriteLine("Failed");
                        }
                        break;

                    case 3:
                        Console.WriteLine("Enter Account Number:");
                        long wAcc = long.Parse(Console.ReadLine());

                        Console.WriteLine("Enter Amount to Withdraw:");
                        float wAmt = float.Parse(Console.ReadLine());

                        float newWBal = bank.Withdraw(wAcc, wAmt);
                        Console.WriteLine(newWBal != -1 ? $"New Balance: {newWBal}" : "Withdrawal failed.");
                        break;

                    case 4:
                        Console.WriteLine("Enter Account Number:");
                        long bAcc = long.Parse(Console.ReadLine());

                        float balance = bank.GetAccountBalance(bAcc);
                        Console.WriteLine(balance != -1 ? $"Balance: {balance}" : "Account not found.");
                        break;

                    case 5:
                        Console.WriteLine("enter from account number:");
                        long fromAcc = long.Parse(Console.ReadLine());

                        Console.WriteLine("enter to Account Number:");
                        long toAcc = long.Parse(Console.ReadLine());

                        Console.WriteLine("Enter Amount to Transfer:");
                        float transAmt = float.Parse(Console.ReadLine());

                        bank.Transfer(fromAcc, toAcc, transAmt);
                        break;

                    case 6:
                        Console.WriteLine("Enter Account Number:");
                        long detAcc = long.Parse(Console.ReadLine());
                        bank.GetAccountDetails(detAcc);
                        break;

                    case 7:
                        return;

                    default:
                        Console.WriteLine("invalid choice.");
                        break;
                }


            }

        }
    }