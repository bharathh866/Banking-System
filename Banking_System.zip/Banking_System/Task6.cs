﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_System
{
    internal class Task6
    {

        static void Main(String[] args)
        {
            List<string> transactions = new List<string>();
            bool val= true;

            while (val)
            {
        
                Console.WriteLine("1. Deposit");
                Console.WriteLine("2. Withdraw");
                Console.WriteLine("3. Exit and Show History");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        Console.Write("enter deposit amount");
                        string deposit = Console.ReadLine();
                        transactions.Add($"Deposited:{deposit}");
                        break;

                    case "2":
                        Console.Write("enter withdrawal amount");
                        string withdraw = Console.ReadLine();
                        transactions.Add($"Withdraw:{withdraw}");
                        break;

                    case "3":
                        val = false;
                        break;

                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
            }

            Console.WriteLine(" Transaction History");
            foreach (string t in transactions)
            {
                Console.WriteLine(t);
            }
        }
    }
}