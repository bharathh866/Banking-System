﻿
//using Banking_System;
//using System;
//using System.Collections.Generic;
//using System.Dynamic;
//using System.Net.NetworkInformation;
//using System.Security.Policy;
//using System.Security.Principal;
//using System.Xml.Linq;
//namespace _System
//{


//    Task 9: Abstraction
//1. Create an abstract class BankAccount that represents a generic bank account.It should include the following attributes and methods:
//
//Attributes:
//o Account number.
//    o Customer name.
//o Balance.
//
//Constructors:
//o Implement default constructors and overload the constructor with Account attributes, generate getter and setter, print all information of attribute methods for the attributes.
//
//Abstract methods:
//o deposit(amount: float): Deposit the specified amount into the account.
//o withdraw(amount: float): Withdraw the specified amount from the account(implement error handling for insufficient funds).
//o calculate_interest(): Abstract method for calculating interest
//    public abstract class BankAccount
//    {
//        public string AccountNumber;
//        public string CustomerName;
//        public float Balance;

//        public BankAccount()
//        {

//        }
//        public BankAccount(string accountnumber, string customername, float accountbalance)
//        {
//            AccountNumber = accountnumber;
//            CustomerName = customername;
//            Balance = accountbalance;
//        }
//        public void SetAccountNumber(string accountnumber)
//        {
//            AccountNumber = accountnumber;
//        }
//        public void SetCustomerName(string customername)
//        {
//            CustomerName = customername;

//        }
//        public void SetBalance(float balance)
//        {
//            Balance = balance;
//        }

//        public string GetAccountNumber()
//        {
//            return AccountNumber;
//        }
//        public string GetCustomerName()
//        {
//            return CustomerName;

//        }
//        public float GetBalance()
//        {
//            return Balance;
//        }

//        public void DisplayAccountInfo()
//        {
//            Console.WriteLine("Displaying Account Details");
//            Console.WriteLine("Account Number: " + AccountNumber);
//            Console.WriteLine("Customer Name: " + CustomerName);
//            Console.WriteLine("Account Balance: " + Balance);


//        }
//        public abstract void deposit(float amount);
//        public abstract void withdraw(float amount);
//        public abstract void calculate_intrest();
//    }

//    2. Create two concrete classes that inherit from BankAccount:
//
//SavingsAccount: A savings account that includes an additional attribute for interest rate.Implement the calculate_interest() method to calculate interest based on the balance and interest rate.
//
//CurrentAccount: A current account with no interest. Implement the withdraw() method to allow overdraft up to a certain limit (configure a constant for the overdraft limit).
//    public class SavingsAccount : BankAccount
//    {
//        float intrestRate = 0.6f;

//        public SavingsAccount(string accountnumber, string customername, float balance)
//        {
//            AccountNumber = accountnumber;
//            CustomerName = customername;
//            Balance = balance;
//        }
//        public override void calculate_intrest()
//        {
//            float intrest = intrestRate * Balance;
//            Console.WriteLine("Interest:" + intrest);
//            Balance += intrest;
//        }
//        public override void deposit(float amount)
//        {
//            Balance += amount;
//        }
//        public override void withdraw(float amount)
//        {
//            if (amount > Balance)
//            {
//                Console.WriteLine("Insufficient Balance");
//            }
//            else
//            {
//                Balance -= amount;
//            }

//        }

//    }
//    public class CurrentAccount : BankAccount
//    {
//        float overdraftLimit = 2000;
//        public CurrentAccount(string accountnumber, string customername, float balance)
//        {
//            AccountNumber = accountnumber;
//            CustomerName = customername;
//            Balance = balance;
//        }
//        public override void withdraw(float amount)
//        {
//            if (Balance - amount > -overdraftLimit)
//            {
//                Balance -= amount;
//            }
//        }
//        public override void deposit(float amount)
//        {
//            Balance += amount;
//        }


//        public override void calculate_intrest()
//        {
//            Console.WriteLine("Not availabele for Current Account");
//        }
//    }
//    class Bank
//    {
//        3. Create a Bank class to represent the banking system.Perform the following operation in main method:
//
//Display menu for user to create object for account class by calling parameter constructor.Menu should display options `SavingsAccount` and `CurrentAccount`. user can choose any one option to create account.use switch case for implementation.create_account should display sub menu to choose type of accounts.
//o Hint: Account acc = new SavingsAccount(); or Account acc = new CurrentAccount();
//
//deposit(amount: float) : Deposit the specified amount into the account.
//
//withdraw(amount: float) : Withdraw the specified amount from the account.For saving account withdraw amount only if there is sufficient fund else display insufficient balance.For Current Account withdraw limit can exceed the available balance and should not exceed the overdraft limit.
//        static void Main(String[] args)
//        {
//            Console.WriteLine("Enter the account type_ ");
//            string acc = Console.ReadLine();
//            BankAccount account = null;

//            switch (acc)
//            {
//                case "s":
//                    Console.WriteLine("Enter Account num");
//                    string accountnumber = Console.ReadLine();


//                    account = new SavingsAccount(accountnumber, "Savings", 0);

//                    break;
//                case "c":

//                    Console.WriteLine("Enter Account num");
//                    string accountnum = Console.ReadLine();

//                    account = new CurrentAccount(accountnum, "Current", 0);

//                    break;

//                default:
//                    Console.WriteLine("Invalid Operation");
//                    break;
//            }



//            while (true)
//            {
//                Console.WriteLine("Enter " +
//                "1. Deposit" + " 2.Withdraw" + "3.Calculate intrest" + "4. Show balance" + "5.Exit");
//                int choice = int.Parse(Console.ReadLine());
//                switch (choice)
//                {
//                    case 1:
//                        Console.WriteLine("Enter Amount to deposit");
//                        float depositamt = float.Parse(Console.ReadLine());
//                        account.deposit(depositamt);
//                        break;

//                    case 2:
//                        Console.WriteLine("Enter Amount to withdraw");
//                        float withdrawamt = float.Parse(Console.ReadLine());
//                        account.withdraw(withdrawamt);
//                        break;

//                    case 3:

//                        account.calculate_intrest();
//                        break;

//                    case 4:
//                        account.DisplayAccountInfo();
//                        break;


//                }

//                if (choice == 5)
//                {
//                    break;
//                }

//            }
//            Console.ReadLine();
//        }
//    }
//}
