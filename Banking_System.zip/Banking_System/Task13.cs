﻿using Banking_System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    public class Customers
    {
        public int CustomerID { get; set; }
        public string Name { get; set; }

        public Customers(int id, string name)
        {
            CustomerID = id;
            Name = name;
        }

       
    }

    public class Accounts
    {
        public long AccountNumber { get; set; }
        public Customer Customer { get; set; }
        public float Balance { get; set; }

        public Accounts(long accNo, Customers cust, float balance)
        {
            AccountNumber = accNo;
            Customer = cust;
            Balance = balance;
        }
    }
    public class BankList
    {
        private List<Accounts> accounts = new List<Accounts>();

        public void AddAccount(Accounts acc)
        {
            accounts.Add(acc);
        }
       
        
    }
    public class BankSet
    {
        private HashSet<Account> accounts = new HashSet<Account>();

        public void AddAccount(Account acc)
        {
            if (!accounts.Add(acc))
                Console.WriteLine("Duplicate Account. Not added.");
        }

        public void ListAccounts()
        {
            var sorted = accounts.ToList();
            

            foreach (var acc in sorted)
                Console.WriteLine(acc);
        }
    }
    public class BankMap
    {
        private Dictionary<long, Account> accounts = new Dictionary<long, Account>();

        public void AddAccount(Account acc)
        {
            if (!accounts.ContainsKey(acc.AccountNumber))
                accounts[acc.AccountNumber] = acc;
            else
                Console.WriteLine("Duplicate AccountNumber. Not added.");
        }

        public void ListAccounts()
        {
            var sorted = accounts.Values.ToList();
     

            foreach (var acc in sorted)
                Console.WriteLine(acc);
        }
    }
}
internal class Task13
    {
    static void Main(string[] args)
    {
        var customer1 = new Customers(101, "Raj");
        var customer2 = new Customers(102, "ramesh");
        var customer3 = new Customers(103, "Ben");

        var acc1 = new Accounts(1001, customer1, 5000);
        var acc2 = new Accounts(1002, customer2, 3000);
        var acc3 = new Accounts(1003, customer3, 7000);
      

  
        var bankList = new BankList();
        bankList.AddAccount(acc1);
        bankList.AddAccount(acc2);
        bankList.AddAccount(acc3);
  
        var bankSet = new BankSet();
        bankSet.AddAccount(acc1);
        bankSet.AddAccount(acc2);
        bankSet.AddAccount(acc3);
        bankSet.AddAccount(acc4); 
        bankSet.ListAccounts();

        var bankMap = new BankMap();
        bankMap.AddAccount(acc1);
        bankMap.AddAccount(acc2);
        bankMap.AddAccount(acc3);
        bankMap.AddAccount(acc4); 
        bankMap.ListAccounts();
    } 
}
