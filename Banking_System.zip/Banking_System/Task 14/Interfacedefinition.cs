﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Banking_System.classImplement.ZeroBalanceAccount;

namespace Banking_System.interfacedefinition
{
    public interface ICustomerServiceProvider
    {
        float GetAccountBalance(long accountNumber);

        float Deposit(long accountNumber, float amount);

        float Withdraw(long accountNumber, float amount);

        void Transfer(long fromAccountNumber, long toAccountNumber, float amount);

        Account GetAccountDetails(long accountNumber);

        List<Transaction> GetTransactions(long accountNumber, DateTime fromDate, DateTime toDate);
    }
    public interface IBankServiceProvider
    {
        Account CreateAccount(Customer customer, long accNo, string accType, float balance);

        List<Account> ListAccounts();

        Account GetAccountDetails(long accountNumber);

        void CalculateInterest();
    }
    public interface IBankRepository
    {
        void CreateAccount(Customer customer, long accNo, string accType, float balance);

        List<Account> ListAccounts();

        void CalculateInterest();

        float GetAccountBalance(long accountNumber);

        float Deposit(long accountNumber, float amount);

        float Withdraw(long accountNumber, float amount);

    }
    internal class Interfacedefinition
    {
    }
}
