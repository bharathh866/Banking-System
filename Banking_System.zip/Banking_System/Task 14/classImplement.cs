﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace Banking_System.classImplement
{

    public class Customer
    {
        public Customer(int id, string firstName, string lastName, string email, string phone, string address)
        {
            CustomerID = id;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Phone = phone;
            Address = address;
        }
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        private string email;
        public string Email
        {
            get => email;
            set
            {
              
            }
        }

        private string phone;
        public string Phone
        {
            get => phone;
            set
            {
                if (!Regex.IsMatch(value, @"^\d{10}$"))
                    throw new ArgumentException("Phone number must be 10 digits.");
                phone = value;
            }
        }

        public string Address { get; set; }

        public Customer() { }

        

        public void PrintDetails()
        {
            Console.WriteLine($"{CustomerID} | {FirstName} {LastName} | {Email} | {Phone} | {Address}");
        }
    }
    public class Account
    {
        private static long lastAccNo = 1000;
        public long AccountNumber { get; }
        public string AccountType { get; set; }
        public float AccountBalance { get; set; }
        public Customer Customer { get; set; }

        protected Account(string accountType, float balance, Customer customer)
        {
            AccountNumber = ++lastAccNo;
            AccountType = accountType;
            AccountBalance = balance;
            Customer = customer;
        }

   
    }

    public class SavingsAccount : Account
    {
        public float InterestRate { get; set; }

        public SavingsAccount(float balance, Customer cust, float interestRate = 3.5f)
            : base("Savings", balance < 500 ? throw new ArgumentException("Minimum balance 500") : balance, cust)
        {
            InterestRate = interestRate;
        }

      
    }

    public class CurrentAccount : Account
    {
        public float OverdraftLimit { get; set; }

        public CurrentAccount(float balance, Customer cust, float overdraftLimit = 10000)
            : base("Current", balance, cust)
        {
            OverdraftLimit = overdraftLimit;
        }

       
    }

    public class ZeroBalanceAccount : Account
    {
        private Banking_System.Customer customer;

        public ZeroBalanceAccount(Customer cust)
            : base("ZeroBalance", 0, cust)
        {
        }

        public ZeroBalanceAccount(Customer customer)
        {
            this.customer = customer;
        }

        public override void PrintAccountDetails()
        {
            Console.WriteLine($"[ZeroBalance] Acc#: {AccountNumber}, Balance: {AccountBalance}");
            Customer.PrintDetails();
        }
        public enum TransactionType { Withdraw, Deposit, Transfer }

        public class Transaction
        {
            public long AccountNumber { get; set; }
            public string Description { get; set; }
            public DateTime DateTime { get; set; }
            public TransactionType Type { get; set; }
            public float Amount { get; set; }

            public Transaction(long accNo, string desc, TransactionType type, float amount)
            {
                AccountNumber = accNo;
                Description = desc;
                DateTime = DateTime.Now;
                Type = type;
                Amount = amount;
            }

            public void PrintTransaction()
            {
                Console.WriteLine($"{DateTime} | {Type} | {Amount} | {Description}");
            }
        }
    }
        internal class classImplement
    {
    }
}
