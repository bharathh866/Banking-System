﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_System.dbconnect
{

    public static class DBUtil
    {

        public static SqlConnection GetDBConnection()
        {
            return new SqlConnection("Server=BHARATH_S\\MSSQLSERVER08;Initial Catalog=Banking;Integrated security=True");
        }
    }
    internal class DBConnect
    {
    }
}

