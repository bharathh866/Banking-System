﻿using Banking_System.implementation;
using Banking_System.interfacedefinition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Banking_System.classImplement.ZeroBalanceAccount;
using Banking_System.classImplement;
namespace Banking_System.Task_14
{


    class BankApp
    {
        static void Main(string[] args)
        {
            IBankRepository bankRepo = new BankRepositoryImpl();

            while (true)
            {
                Console.WriteLine("1. Create Account");
                Console.WriteLine("2. Deposit");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Get Balance");  
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");

                int choice = int.Parse(Console.ReadLine());
                try
                {
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Choose Account Type: 1. Savings 2. Current 3. ZeroBalance");
                            int accType = int.Parse(Console.ReadLine());

                            Console.Write("Customer ID: ");
                            int custId = int.Parse(Console.ReadLine());
                            Console.Write("First Name: ");
                            string first = Console.ReadLine();
                            Console.Write("Last Name: ");
                            string last = Console.ReadLine();
                            Console.Write("Email: ");
                            string email = Console.ReadLine();
                            Console.Write("Phone: ");
                            string phone = Console.ReadLine();
                            Console.Write("Address: ");
                            string address = Console.ReadLine();

                            Customer cust = new Customer(custId, first, last, email, phone, address);
                            float balance = 0;

                            if (accType == 1)
                            {
                                balance = 500;
                                bankRepo.CreateAccount(cust, 0, "Savings", balance);
                            }
                            else if (accType == 2)
                            {
                                Console.Write("Initial Balance: ");
                                balance = float.Parse(Console.ReadLine());
                                bankRepo.CreateAccount(cust, 0, "Current", balance);
                            }
                            else
                            {
                                bankRepo.CreateAccount(cust, 0, "ZeroBalance", 0);
                            }

                            Console.WriteLine("Account Created Successfully.");
                            break;

                        case 2:
                            Console.Write("Enter Account Number:");
                            long depAcc = long.Parse(Console.ReadLine());
                            Console.Write("Enter Amount to Deposit:");
                            float depAmt = float.Parse(Console.ReadLine());
                            float newBal = bankRepo.Deposit(depAcc, depAmt);
                            Console.WriteLine($"New Balance: {newBal}");
                            break;

                        case 3:
                            Console.Write("Enter Account Number: ");
                            long withAcc = long.Parse(Console.ReadLine());
                            Console.Write("Enter Amount to Withdraw: ");
                            float withAmt = float.Parse(Console.ReadLine());
                            float bal = bankRepo.Withdraw(withAcc, withAmt);
                            Console.WriteLine($"New Balance: {bal}");
                            break;

                        case 4:
                            Console.Write("Enter Account Number: ");
                            long balAcc = long.Parse(Console.ReadLine());
                            float currentBal = bankRepo.GetAccountBalance(balAcc);
                            Console.WriteLine($"Current Balance: {currentBal}");
                            break;

                        case 5:
                            Console.WriteLine("Exiting Application...");
                            return;

                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }
    }
}
