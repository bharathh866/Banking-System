﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Banking_System.classImplement;
using Banking_System.dbconnect;
using Banking_System.interfacedefinition;
using static Banking_System.classImplement.ZeroBalanceAccount;

namespace Banking_System.implementation
{
    public class CustomerServiceProviderImpl : ICustomerServiceProvider
    {
        protected List<Account> accounts = new List<Account>();
        protected List<Transaction> transactions = new List<Transaction>();

        public float GetAccountBalance(long accountNumber)
        {
            Account acc = accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            if (acc == null) throw new Exception("Account not found");
            return acc.AccountBalance;
        }

        public float Deposit(long accountNumber, float amount)
        {
            Account acc = accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            if (acc == null) throw new Exception("Account not found");
            acc.AccountBalance += amount;
            transactions.Add(new Transaction(accountNumber, "Deposit", TransactionType.Deposit, amount));
            return acc.AccountBalance;
        }

        public float Withdraw(long accountNumber, float amount)
        {
            Account acc = accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            if (acc == null) throw new Exception("Account not found");

            if (acc is SavingsAccount)
            {
                if (acc.AccountBalance - amount < 500)
                    throw new Exception("Minimum balance of 500 must be maintained.");
            }
            else if (acc is CurrentAccount current)
            {
                if (acc.AccountBalance + current.OverdraftLimit < amount)
                    throw new Exception("Exceeds overdraft limit.");
            }
            else if (acc.AccountBalance < amount)
            {
                throw new Exception("Insufficient funds.");
            }

            acc.AccountBalance -= amount;
            transactions.Add(new Transaction(accountNumber, "Withdraw", TransactionType.Withdraw, amount));
            return acc.AccountBalance;
        }

        public void Transfer(long fromAccountNumber, long toAccountNumber, float amount)
        {
            Account from = accounts.FirstOrDefault(a => a.AccountNumber == fromAccountNumber);
            Account to = accounts.FirstOrDefault(a => a.AccountNumber == toAccountNumber);
            if (from == null || to == null) throw new Exception("Invalid account number(s)");

            Withdraw(fromAccountNumber, amount);
            Deposit(toAccountNumber, amount);

            transactions.Add(new Transaction(fromAccountNumber, $"Transfer to {toAccountNumber}", TransactionType.Transfer, amount));
            transactions.Add(new Transaction(toAccountNumber, $"Transfer from {fromAccountNumber}", TransactionType.Transfer, amount));
        }

        public Account GetAccountDetails(long accountNumber)
        {
            Account acc = accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            if (acc == null) throw new Exception("Account not found");
            return acc;
        }

        public List<Transaction> GetTransactions(long accountNumber, DateTime fromDate, DateTime toDate)
        {
            return transactions.FindAll(t => t.AccountNumber == accountNumber && t.DateTime >= fromDate && t.DateTime <= toDate);
        }

        List<ZeroBalanceAccount.Transaction> ICustomerServiceProvider.GetTransactions(long accountNumber, DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }
    }
    public class BankServiceProviderImpl : CustomerServiceProviderImpl, IBankServiceProvider
    {
        private string branchName;
        private string branchAddress;

        public BankServiceProviderImpl(string name, string address)
        {
            branchName = name;
            branchAddress = address;
        }

        public Account CreateAccount(Customer customer, long accNo, string accType, float balance)
        {
            Account account = null;
            switch (accType)
            {
                case "savings":
                    new SavingsAccount(balance, customer);  

                    break;
                case "current":
                    account = new CurrentAccount(balance, customer);
                    break;
                case "zerobalance":
                    account = new ZeroBalanceAccount(customer);
                    break;
                default:
                    throw new ArgumentException("Invalid account type.");
            }

            accounts.Add(account);
            return account;
        }

        public List<Account> ListAccounts()
        {
            return accounts;
        }

        public new Account GetAccountDetails(long accountNumber)
        {
            return base.GetAccountDetails(accountNumber);
        }

        public void CalculateInterest()
        {
            foreach (var acc in accounts)
            {
                if (acc is SavingsAccount savings)
                {
                    float interest = savings.AccountBalance * (savings.InterestRate / 100);
                    savings.AccountBalance += interest;
                    transactions.Add(new Transaction(savings.AccountNumber, "Interest Added", TransactionType.Deposit, interest));
                }
            }
        }

    }
    public class BankRepositoryImpl : IBankRepository
    {
        public void CreateAccount(Customer customer, long accNo, string accType, float balance)
        {
            using (SqlConnection conn = DBUtil.GetDBConnection())
            {
                conn.Open();
                string insertCustomer = "INSERT INTO Customers (CustomerID, FirstName, LastName, Email, Phone, Address) VALUES (@id, @fn, @ln, @em, @ph, @ad)";
                string insertAccount = "INSERT INTO Accounts (AccountNumber, AccountType, Balance, CustomerID) VALUES (@accNo, @type, @bal, @custId)";

                using (SqlCommand cmd1 = new SqlCommand(insertCustomer, conn))
                {
                    cmd1.Parameters.AddWithValue("@id", customer.CustomerID);
                    cmd1.Parameters.AddWithValue("@fn", customer.FirstName);
                    cmd1.Parameters.AddWithValue("@ln", customer.LastName);
                    cmd1.Parameters.AddWithValue("@em", customer.Email);
                    cmd1.Parameters.AddWithValue("@ph", customer.Phone);
                    cmd1.Parameters.AddWithValue("@ad", customer.Address);
                    cmd1.ExecuteNonQuery();
                }

                using (SqlCommand cmd2 = new SqlCommand(insertAccount, conn))
                {
                    cmd2.Parameters.AddWithValue("@accNo", accNo);
                    cmd2.Parameters.AddWithValue("@type", accType);
                    cmd2.Parameters.AddWithValue("@bal", balance);
                    cmd2.Parameters.AddWithValue("@custId", customer.CustomerID);
                    cmd2.ExecuteNonQuery();
                }
            }
        }

        public List<Account> ListAccounts()
        {
            List<Account> accounts = new List<Account>();
            using (SqlConnection conn = DBUtil.GetDBConnection())
            {
                conn.Open();
                string query = "select * from Accounts a join Customers c ON a.CustomerID = c.CustomerID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var customer = new Customer(
                            (int)reader["CustomerID"],
                            reader["FirstName"].ToString(),
                            reader["LastName"].ToString(),
                            reader["Email"].ToString(),
                            reader["Phone"].ToString(),
                            reader["Address"].ToString()
                        );
                        var accType = reader["AccountType"].ToString().ToLower();
                        var balance = Convert.ToSingle(reader["Balance"]);
                        Account acc = accType switch
                        {
                            "savings" => new SavingsAccount(balance, customer),
                            "current" => new CurrentAccount(balance, customer),
                            "zerobalance" => new ZeroBalanceAccount(customer)
                          
                        };
                        accounts.Add(acc);
                    }
                }
            }
            return accounts;
        }

        public void CalculateInterest()
        {
            List<Account> savingsAccounts = ListAccounts().FindAll(a => a is SavingsAccount);
            using (SqlConnection conn = DBUtil.GetDBConnection())
            {
                conn.Open();
                foreach (SavingsAccount acc in savingsAccounts)
                {
                    float interest = acc.AccountBalance * (acc.InterestRate / 100);
                    acc.AccountBalance += interest;
                    string update = "update Accounts set Balance = @bal where AccountNumber = @accNo";
                    using (SqlCommand cmd = new SqlCommand(update, conn))
                    {
                        cmd.Parameters.AddWithValue("@bal", acc.AccountBalance);
                        cmd.Parameters.AddWithValue("@accNo", acc.AccountNumber);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public float GetAccountBalance(long accountNumber)
        {
            using (SqlConnection conn = DBUtil.GetDBConnection())
            {
                conn.Open();
                string query = "select Balance from Accounts where AccountNumber = @accNo";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@accNo", accountNumber);
                    return Convert.ToSingle(cmd.ExecuteScalar());
                }
            }
        }

        public float Deposit(long accountNumber, float amount)
        {
            float current = GetAccountBalance(accountNumber);
            float updated = current + amount;
            using (SqlConnection conn = DBUtil.GetDBConnection())
            {
                conn.Open();
                string update = "update Accounts set Balance = @bal where AccountNumber = @accNo";
                using (SqlCommand cmd = new SqlCommand(update, conn))
                {
                    cmd.Parameters.AddWithValue("@bal", updated);
                    cmd.Parameters.AddWithValue("@accNo", accountNumber);
                    cmd.ExecuteNonQuery();
                }
                string txn = "insert into Transactions (AccountNumber, Description, DateTime, Type, Amount) values (@accNo, @desc, GETDATE(), 'Deposit', @amt)";
                using (SqlCommand cmd = new SqlCommand(txn, conn))
                {
                    cmd.Parameters.AddWithValue("@accNo", accountNumber);
                    cmd.Parameters.AddWithValue("@desc", "Cash Deposit");
                    cmd.Parameters.AddWithValue("@amt", amount);
                    cmd.ExecuteNonQuery();
                }
            }
            return updated;
        }

        public float Withdraw(long accountNumber, float amount)
        {
            float balance = GetAccountBalance(accountNumber);
            if (balance < amount)
                throw new Exception("Insufficient funds");

            float updated = balance - amount;
            using (SqlConnection conn = DBUtil.GetDBConnection())
            {
                conn.Open();
                string update = "update Accounts set Balance = @bal where AccountNumber = @accNo";
                using (SqlCommand cmd = new SqlCommand(update, conn))
                {
                    cmd.Parameters.AddWithValue("@bal", updated);
                    cmd.Parameters.AddWithValue("@accNo", accountNumber);
                    cmd.ExecuteNonQuery();
                }
                string txn = "insert into Transactions (AccountNumber, Description, DateTime, Type, Amount) values (@accNo, @desc, GETDATE(), 'Withdraw', @amt)";
                using (SqlCommand cmd = new SqlCommand(txn, conn))
                {
                    cmd.Parameters.AddWithValue("@accNo", accountNumber);
                    cmd.Parameters.AddWithValue("@desc", "Cash Withdraw");
                    cmd.Parameters.AddWithValue("@amt", amount);
                    cmd.ExecuteNonQuery();
                }
            }
            return updated;
        }

        internal class Interfaceimplementaation
        {
        }
    }
}


