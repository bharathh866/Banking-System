﻿//using System;
//using System.Collections.Generic;


//namespace Banking_System
//{
//    Task 7: Class & Object
//    1. Create a `Customer` class with the following confidential attributes:
//    class Customer
//    {
//        public int CustomerID;
//        public string FirstName;
//        public string LastName;
//        public string EmailAddress;
//        public string PhoneNumber;
//        public string Address;
//        public Customer()
//        {
//            Console.WriteLine("Customer default customer invoked");
//        }
//        public Customer(int customerID, string firstName, string lastName, string emailAddress, string phoneNumber, string address)
//        {
//            CustomerID = customerID;
//            FirstName = firstName;
//            LastName = lastName;
//            EmailAddress = emailAddress;
//            PhoneNumber = phoneNumber;
//            Address = address;
//        }
//        public void SetCustomerID(int id)
//        {
//            CustomerID = id;
//        }
//        public void SetFirstName(string firstName)
//        {
//            FirstName = firstName;
//        }
//        public void SetLastName(string lastName)
//        {
//            LastName = lastName;
//        }
//        public void SetemailAddress(string emailaddress)
//        {
//            EmailAddress = emailaddress;
//        }
//        public void SetPhonenumber(string phonenumber)
//        {
//            PhoneNumber = phonenumber;
//        }
//        public void SetAddress(string address)
//        {
//            Address = address;
//        }
//        public int GetCustomerID()
//        {
//            return CustomerID;
//        }
//        public string GetFirstName()
//        {
//            return FirstName;
//        }
//        public string GetLastName()
//        {
//            return LastName;
//        }
//        public string GetemailAddress()
//        {
//            return EmailAddress;
//        }
//        public string GetPhonenumber()
//        {
//            return PhoneNumber;
//        }
//        public string GetAddress()
//        {
//            return Address;
//        }
//        public void DisplayCustomerInfo()
//        {
//            Console.WriteLine("Customer ID: " + CustomerID);
//            Console.WriteLine("Customer Name: " + FirstName);
//            Console.WriteLine("Customer Email: " + LastName);
//            Console.WriteLine("Email:" + EmailAddress);
//            Console.WriteLine("phone number:" + PhoneNumber);
//            Console.WriteLine("Address:" + Address);

//        }
//    }
//    2. Create an `Account` class with the following confidential attributes:
//    public class Account
//    {
//        public string AccountNumber;
//        public string AccountType;
//        public float AccountBalance;

//        public Account()
//        {

//        }
//        public Account(string accountnumber, string accounttype, float accountbalance)
//        {
//            AccountNumber = accountnumber;
//            AccountType = accounttype;
//            AccountBalance = accountbalance;
//        }

//        public void SetAccountNumber(string accountnumber)
//        {
//            AccountNumber = accountnumber;
//        }
//        public void SetAccountType(string accounttype)
//        {
//            AccountType = accounttype;
//        }
//        public void SetAccountBalance(float accountbalance)
//        {
//            AccountBalance = accountbalance;
//        }

//        public string GetAccountnumber()
//        {
//            return AccountNumber;
//        }
//        public string GetAccountType()
//        {
//            return AccountType;

//        }
//        public float GetAccountBalance()
//        {
//            return AccountBalance;
//        }
//        public void DisplayAccountInfo()
//        {
//            Console.WriteLine("Displaying Account Details");
//            Console.WriteLine("Account Number: " + AccountNumber);
//            Console.WriteLine("Account Type: " + AccountType);
//            Console.WriteLine("Account Balance: " + AccountBalance);


//        }
//        Task 8: Inheritance and polymorphism
//        1. Overload the deposit and withdraw methods in Account class as mentioned below.
//deposit(amount: float): Deposit the specified amount into the account.
//
//withdraw(amount: float) : Withdraw the specified amount from the account.withdraw amount only if there is sufficient fund else display insufficient balance.
//
//deposit(amount: int) : Deposit the specified amount into the account.
//
//withdraw(amount: int) : Withdraw the specified amount from the account.withdraw amount only if there is sufficient fund else display insufficient balance.
//
//deposit(amount: double) : Deposit the specified amount into the account.
//
//withdraw(amount: double) : Withdraw the specified amount from the account.withdraw amount only if there is sufficient fund else display insufficient balance.

//        public void deposit(float amount)
//        {
//            AccountBalance += amount;
//        }
//        public void deposit(int amount)
//        {
//            AccountBalance += amount;
//        }
//        public void deposit(double amount)
//        {
//            AccountBalance += (float)amount;
//        }


//        public virtual void withdraw(float amount)
//        {
//            if (amount > AccountBalance)
//            {
//                Console.WriteLine("Insufficient Balance");
//            }
//            else
//            {
//                AccountBalance -= amount;
//            }

//        }
//        public void withdraw(int amount)
//        {
//            if (amount > AccountBalance)
//            {
//                Console.WriteLine("Insufficient Balance");
//            }
//            else
//            {
//                AccountBalance -= amount;
//            }

//        }
//        public void withdraw(double amount)
//        {
//            if (amount > AccountBalance)
//            {
//                Console.WriteLine("Insufficient Balance");
//            }
//            else
//            {
//                AccountBalance -= (float)amount;
//            }

//        }
//        public virtual void calculate_interest()
//        {
//            Console.WriteLine("Interest Amount:" + AccountBalance * 0.045);
//        }
//    }
//    2. Create Subclasses for Specific Account Types
//


//Create subclasses for specific account types(e.g., `SavingsAccount`, `CurrentAccount`) that inherit from the `Account` class.
//o SavingsAccount: A savings account that includes an additional attribute for interest rate. override the calculate_interest() from Account class method to calculate interest based on the balance and interest rate.
//o CurrentAccount: A current account that includes an additional attribute overdraftLimit.A current account with no interest. Implement the withdraw() method to allow overdraft up to a certain limit (configure a constant for the overdraft limit).


//    public class SavingsAccount : Account
//    {
//        float intrestRate = 0.6f;

//        public SavingsAccount(string accountnumber, string accountype, float balance)
//        {
//            AccountNumber = accountnumber;
//            AccountType = accountype;
//            AccountBalance = balance;
//        }
//        public override void calculate_interest()
//        {
//            float intrest = intrestRate * AccountBalance;
//            Console.WriteLine("Interest:" + intrest);
//            AccountBalance += intrest;
//        }


//    }
//    public class CurrentAccount : Account
//    {
//        float overdraftLimit = 2000;
//        public CurrentAccount(string accountnumber, string accountype, float balance)
//        {
//            AccountNumber = accountnumber;
//            AccountType = accountype;
//            AccountBalance = balance;
//        }
//        public override void withdraw(float amount)
//        {
//            if (AccountBalance - amount > -overdraftLimit)
//            {
//                AccountBalance -= amount;
//            }
//        }
//        public override void calculate_interest()
//        {
//            Console.WriteLine("Not availabele for Current Account");
//        }
//    }

//    Create a Bank class to represent the banking system.Perform the following operation in main method:
//    class Bank
//    {
//        static void Main(string[] args)
//        {
//            Customer c2 = new Customer();
//            Customer c1 = new Customer(801, "Arun", "kumar", "arun@gmail.com", "8753689701", "167 Mogappair east");
//            c1.DisplayCustomerInfo();

//            c2.SetCustomerID(802);
//            c2.SetFirstName("Sathish");
//            c2.SetLastName("Kumar");
//            c2.SetemailAddress("sat@gmail.com");
//            c2.SetPhonenumber("9326909212");
//            c2.SetAddress("187 Aynambakkam");

//            c2.GetCustomerID();
//            c2.GetFirstName();
//            c2.GetLastName();
//            c2.GetemailAddress();
//            c2.GetPhonenumber();
//            c2.GetAddress();
//            c2.DisplayCustomerInfo();


//            Account ac = new Account("13001645", "Savings", 85000);
//            ac.DisplayAccountInfo();
//            ac.deposit(3000);
//            ac.withdraw(10000);
//            ac.calculate_interest();
//            ac.DisplayAccountInfo();



//            Display menu for user to create object for account class by calling
//            parameter constructor.Menu should display options
//            `SavingsAccount` and `CurrentAccount`.
//            user can choose any one option to create account.use switch case for implementation.

//        Console.WriteLine("Enter the account type ");
//            string acc = Console.ReadLine();
//        Account account = null;

//            switch (acc)
//            {
//                case "s":
//                    Console.WriteLine("Enter Account num");
//                    string accountnumber = Console.ReadLine();


//        account = new SavingsAccount(accountnumber, "Savings", 0);

//                    break;
//                case "c":

//                    Console.WriteLine("Enter Account num");
//                    string accountnum = Console.ReadLine();

//        account = new CurrentAccount(accountnum, "Current", 0);

//                    break;

//                default:
//                    Console.WriteLine("Invalid Operation");
//                    break;
//            }



//            while (true) {
//                Console.WriteLine("Enter " +
//                "1. Deposit" + " 2.Withdraw" + "3.Calculate intrest" + "4. Show balance"+"5.Exit");
//                int choice = int.Parse(Console.ReadLine());
//                switch (choice)
//            {
//                case 1:
//                    Console.WriteLine("Enter Amount to deposit");
//                    float depositamt = float.Parse(Console.ReadLine());
//    account.deposit(depositamt);
//                    break;

//                case 2:
//                    Console.WriteLine("Enter Amount to withdraw");
//                    float withdrawamt = float.Parse(Console.ReadLine());
//    account.withdraw(withdrawamt);
//                    break;

//                case 3:

//                        account.calculate_interest();
//                        break;

//                 case 4:
//                        account.DisplayAccountInfo();
//                        break;


//            }
//if (choice == 5)
//{
//    break;
//}

//        }
//            Console.ReadLine();

//        }
//    }
//}
