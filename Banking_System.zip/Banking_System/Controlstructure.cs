﻿//using _System;
//using System;


//namespace Banking_System
//{
//    internal class Controlstructure
//    {
//        static void Main(String[] args)
//        {
//            {
//                Task 1: Conditional Statements


//                In a bank, you have been given the task is to create a program that checks if a customer is eligible for a loan based on their credit score and income.The eligibility criteria are as follows:
//                
//                Credit Score must be above 700.
//                
//                Annual Income must be at least $50, 000.
//                Tasks:
//                1.Write a program that takes the customer's credit score and annual income as input.
//                2.Use conditional statements(if-else) to determine if the customer is eligible for a loan.
//                3.Display an appropriate message based on eligibility.
//                Console.Write("Enter your Credit Score");
//                int creditScore = Convert.ToInt32(Console.ReadLine());

//                Console.Write("Enter your Annual Income  ");
//                double annualIncome = Convert.ToDouble(Console.ReadLine());


//                if (creditScore > 700 && annualIncome >= 50000)
//                {
//                    Console.WriteLine("You are eligible for a loan");
//                }
//                else
//                {
//                    Console.WriteLine("you are not eligible for a loan");
//                    if (creditScore <= 700)
//                    {
//                        Console.WriteLine("Credit Score must be above 700");
//                    }
//                    if (annualIncome < 50000)
//                    {
//                        Console.WriteLine(" Annual Income must be at least 50,000");
//                    }
//                }

//                Task 2:
//
//                Nested Conditional Statements
//                        Create a program that simulates an ATM transaction
//                       .Display options such as "Check Balance," "Withdraw," "Deposit,".
//                                    Ask the user to enter their current balance and the
//                                    amount they want to withdraw or deposit.Implement checks to ensure
//                                    that the withdrawal amount is not greater than the available balance
//                                    and that the withdrawal amount is in 
//                                    multiples of 100 or 500.Display appropriate messages for success or failure.

//                double balance;

//                Console.Write("Enter your current balance: ");
//                balance = Convert.ToDouble(Console.ReadLine());


//                Console.WriteLine("1 Check Balance");
//                Console.WriteLine("2 Withdraw");
//                Console.WriteLine("3 Deposit");
//                Console.Write("Choose an option (1-3): ");
//                int choice = Convert.ToInt32(Console.ReadLine());

//                if (choice == 1)
//                {
//                    Console.WriteLine($" current balance is: ${balance}");
//                }
//                else if (choice == 2)
//                {
//                    Console.Write("\nEnter amount to withdraw: ");
//                    double withdrawAmount = Convert.ToDouble(Console.ReadLine());

//                    if (withdrawAmount <= balance)
//                    {
//                        if (withdrawAmount % 100 == 0 || withdrawAmount % 500 == 0)
//                        {
//                            balance -= withdrawAmount;
//                            Console.WriteLine($"withdrawal done new balance: ${balance}");
//                        }
//                        else
//                        {
//                            Console.WriteLine("withdrawal amount must be in  100 or 500.");
//                        }
//                    }
//                    else
//                    {
//                        Console.WriteLine("Insufficient balance for withdrawal.");
//                    }
//                }
//                else if (choice == 3)
//                {
//                    Console.Write("Enter amount to deposit: ");
//                    double depositAmount = Convert.ToDouble(Console.ReadLine());

//                    if (depositAmount > 0)
//                    {
//                        balance += depositAmount;
//                        Console.WriteLine($" balance: ${balance}");
//                    }
//                    else
//                    {
//                        Console.WriteLine("deposit amount must be positive.");
//                    }
//                }
//                else
//                {
//                    Console.WriteLine("invalid option.");
//                }

//                Task 3: Loop Structures


//You are responsible for calculating compound interest on savings accounts for bank customers. You need to calculate the future balance for each customer's savings account after a certain number of years.
//Tasks:
//1.Create a program that calculates the future balance of a savings account.
//2.Use a loop structure(e.g., for loop) to calculate the balance for multiple customers.
//3.Prompt the user to enter the initial balance, annual interest rate, and the number of years.
//4.Calculate the future balance using the formula: future_balance = initial_balance * (1 + annual_interest_rate / 100) ^ years.
//5.Display the future balance for each customer.

//                Console.Write("Enter the number of customers: ");
//                int customerCount = Convert.ToInt32(Console.ReadLine());

//                for (int i = 1; i <= customerCount; i++)
//                {

//                    Console.Write("Enter initial balance");
//                    double initialBalance = Convert.ToDouble(Console.ReadLine());

//                    Console.Write("Enter annual interest rate : ");
//                    double annualRate = Convert.ToDouble(Console.ReadLine());

//                    Console.Write("Enter number of years: ");
//                    int years = Convert.ToInt32(Console.ReadLine());

//                    double futureBalance = initialBalance * Math.Pow(1 + annualRate / 100, years);

//                    Console.WriteLine($"Future balance after {years} years: {futureBalance}");
//                }
//                Console.ReadLine();
//            }
//        }
//    }
//}
//Task 4

using System.Collections.Generic;

//class BankApp
//{
//    static void Main()
//    {

//        Dictionary<long, float> accounts = new Dictionary<long, float>
//        {
//            { 1001, 2500.50f },
//            { 1002, 7600.00f },
//            { 1003, 10250.75f },
//            { 1004, 500.00f }
//        };

//        while (true)
//        {
//            Console.Write("Enter your account number  ");
//            string input = Console.ReadLine();


//            if (input == "0")
//                break;

//            if (long.TryParse(input, out long accNo))
//            {
//                if (accounts.ContainsKey(accNo))
//                {
//                    Console.WriteLine($"Account {accNo} Balance:{accounts[accNo]}");
//                }
//                else
//                {
//                    Console.WriteLine("Invalid account number");
//                }
//            }
//            else
//            {
//                Console.WriteLine("Please enter a valid account number.");
//            }

//            Console.WriteLine(); 
//        }

      
//    }
//}
