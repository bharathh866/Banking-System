﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_System
{
    internal class Task5
    {
        static void Main(String[] args)
        {
            Console.WriteLine("Create a password :");
            string password = Console.ReadLine();

            if (IsValidPassword(password))
            {
                Console.WriteLine("password is valid ");
            }
            else
            {
                Console.WriteLine("password is invalid");
                Console.WriteLine("at least 8 characters ");
                Console.WriteLine("contain at least one uppercase");
                Console.WriteLine("contain at one digit");
            }
        }

        static bool IsValidPassword(string password)
        {
            if (password.Length < 8)
                return false;

            bool hasupper = false;
            bool hasdigit = false;

            foreach (char ch in password)
            {
                if (char.IsUpper(ch)) hasupper = true;
                if (char.IsDigit(ch)) hasdigit = true;
            }

            return hasupper && hasdigit;

        }
    }
}