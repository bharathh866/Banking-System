﻿using Hospital_management.dbconnect;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_management
{

    class Doctorhelper
    {
        public static void AddDoctor()
        {
            Console.WriteLine("Enter the Doctor Id:");
            int docid=int.Parse(Console.ReadLine());

            Console.WriteLine("Enter first Name");
            string docfirstname=Console.ReadLine();

            Console.WriteLine("Enter last Name");
            string doclastname=Console.ReadLine();

            Console.WriteLine("Enter specialization");
            string docspecialization=Console.ReadLine();

            Console.WriteLine("Enter Contact  number");
            string doccontactnumber=Console.ReadLine();


            using(SqlConnection conn= DBConnection.GetConnection())
            {
                string addpat = "insert into doctor(doctorId,firstName,lastName,specialization,contactNumber)" +
                    "values(@id,@firstname,@lastname,@specialization,@contactnumber)";

                SqlCommand cmd = new SqlCommand(addpat,conn);
           
                cmd.Parameters.AddWithValue("@id", docid);
                cmd.Parameters.AddWithValue("@firstname", docfirstname);
                cmd.Parameters.AddWithValue("@lastname", doclastname);
                cmd.Parameters.AddWithValue("@specialization", docspecialization);
                cmd.Parameters.AddWithValue("@contactnumber", doccontactnumber);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            } 
        }
    }
    internal class AddDoctor
    {
    }
}
