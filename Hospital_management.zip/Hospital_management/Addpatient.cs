﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hospital_management.dbconnect;

namespace Hospital_management.patient
{
    public static class addPatient
    {
        public static void RegisterPatient()
        {
            Console.Write("Patient ID: ");
            int patientId = int.Parse(Console.ReadLine());

            Console.Write("First Name: ");
            string firstName = Console.ReadLine();

            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();

            Console.Write("Date of Birth (yyyy-MM-dd): ");
            DateTime dob = DateTime.Parse(Console.ReadLine());

            Console.Write("Gender: ");
            string gender = Console.ReadLine();

            Console.Write("Contact Number: ");
            string contact = Console.ReadLine();

            Console.Write("Address: ");
            string address = Console.ReadLine();

            using (SqlConnection conn = DBConnection.GetConnection())
            {
                string query = "INSERT INTO Patient (patientId, firstName, lastName, dateOfBirth, gender, contactNumber, address) " +
                               "VALUES (@id, @fname, @lname, @dob, @gender, @contact, @address)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", patientId);
                cmd.Parameters.AddWithValue("@fname", firstName);
                cmd.Parameters.AddWithValue("@lname", lastName);
                cmd.Parameters.AddWithValue("@dob", dob);
                cmd.Parameters.AddWithValue("@gender", gender);
                cmd.Parameters.AddWithValue("@contact", contact);
                cmd.Parameters.AddWithValue("@address", address);

                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                conn.Close();
            }
        }
    internal class Addpatient
        {
        }
    }
}
