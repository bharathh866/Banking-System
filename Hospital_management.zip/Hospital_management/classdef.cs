﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_management.classes
{
    public class Patient
    {
        private int patientId;
        private string firstName;
        private string lastName;
        private DateTime dateOfBirth;
        private string gender;
        private string contactNumber;
        private string address;

        public Patient() { }

        public Patient(int patientId, string firstName, string lastName, DateTime dateOfBirth, string gender, string contactNumber, string address)
        {
            this.patientId = patientId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.dateOfBirth = dateOfBirth;
            this.gender = gender;
            this.contactNumber = contactNumber;
            this.address = address;
        }

        public int PatientId { get => patientId; set => patientId = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public DateTime DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        public string Gender { get => gender; set => gender = value; }
        public string ContactNumber { get => contactNumber; set => contactNumber = value; }
        public string Address { get => address; set => address = value; }

        public override string ToString()
        {
            return $"PatientId: {patientId}, Name: {firstName} {lastName}, DOB: {dateOfBirth.ToShortDateString()}, Gender: {gender}, Contact: {contactNumber}, Address: {address}";
        }
    }
    public class Doctor
    {
        private int doctorId;
        private string firstName;
        private string lastName;
        private string specialization;
        private string contactNumber;

        public Doctor() { }

        public Doctor(int doctorId, string firstName, string lastName, string specialization, string contactNumber)
        {
            this.doctorId = doctorId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.specialization = specialization;
            this.contactNumber = contactNumber;
        }

        public int DoctorId { get => doctorId; set => doctorId = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Specialization { get => specialization; set => specialization = value; }
        public string ContactNumber { get => contactNumber; set => contactNumber = value; }

        public override string ToString()
        {
            return $"DoctorId: {doctorId}, Name: {firstName} {lastName}, Specialization: {specialization}, Contact: {contactNumber}";
        }
    }
    public class Appointment
    {
        private int appointmentId;
        private int patientId;
        private int doctorId;
        private DateTime appointmentDate;
        private string description;

        public Appointment() { }

        public Appointment(int appointmentId, int patientId, int doctorId, DateTime appointmentDate, string description)
        {
            this.appointmentId = appointmentId;
            this.patientId = patientId;
            this.doctorId = doctorId;
            this.appointmentDate = appointmentDate;
            this.description = description;
        }

        public int AppointmentId { get => appointmentId; set => appointmentId = value; }
        public int PatientId { get => patientId; set => patientId = value; }
        public int DoctorId { get => doctorId; set => doctorId = value; }
        public DateTime AppointmentDate { get => appointmentDate; set => appointmentDate = value; }
        public string Description { get => description; set => description = value; }

        public override string ToString()
        {
            return $"AppointmentId: {appointmentId}, PatientId: {patientId}, DoctorId: {doctorId}, Date: {appointmentDate}, Description: {description}";
        }
    }
    internal class classdef
    {
    }
}
