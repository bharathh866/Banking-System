﻿using Hospital_management.interfacedef;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hospital_management.classes;
using Hospital_management.dbconnect;
using System.ComponentModel.Design;
using Hospital_management.excep;

namespace Hospital_management.interfaceimpl
{
    public class HospitalServiceImpl : IHospitalService
    {
        SqlConnection conn = DBConnection.GetConnection();

        public Appointment GetAppointmentById(int appointmentId)
        {

            using (SqlConnection conn = DBConnection.GetConnection())
            {
                Appointment appt = null;
                string query = "SELECT * FROM Appointment WHERE appointmentId = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", appointmentId);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    appt = new Appointment(
                        (int)reader["appointmentId"],
                        (int)reader["patientId"],
                        (int)reader["doctorId"],
                        (DateTime)reader["appointmentDate"],
                        reader["description"].ToString()
                    );
                }
                conn.Close();
                return appt;
            }
        }

        public List<Appointment> GetAppointmentsForPatient(int patientId)
        {
            using (SqlConnection conn = DBConnection.GetConnection())
            {
                conn.Open();
                string checkQuery = "SELECT COUNT(*) FROM Patient WHERE patientId = @id";
                SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                
                    checkCmd.Parameters.AddWithValue("@id", patientId);
                    int count = (int)checkCmd.ExecuteScalar();

                    if (count == 0)
                    {
                        throw new PatientNumberNotFoundException($"Patient ID {patientId} does not exist.");
                    }
                conn.Close();
            }
            return GetAppointments("SELECT * FROM Appointment WHERE patientId = @id", patientId);
            
        }

        public List<Appointment> GetAppointmentsForDoctor(int doctorId)
        {
            return GetAppointments("SELECT * FROM Appointment WHERE doctorId = @id", doctorId);
        }

        private List<Appointment> GetAppointments(string query, int id)
        {
            using (SqlConnection conn = DBConnection.GetConnection())
            {
                List<Appointment> list = new List<Appointment>();

                
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Appointment(
                        (int)reader["appointmentId"], (int)reader["patientId"],(int)reader["doctorId"],(DateTime)reader["appointmentDate"],  reader["description"].ToString()
                    ));
                }
                conn.Close();
                return list;
            }
        }

        public bool ScheduleAppointment(Appointment appointment)
        {

            using (SqlConnection conn = DBConnection.GetConnection())
            {
                string query = "INSERT INTO Appointment(appointmentId,patientId,doctorId,description,appointmentDate) VALUES (@aid, @pid, @did, @desc,@date)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@aid", appointment.AppointmentId);
                cmd.Parameters.AddWithValue("@pid", appointment.PatientId);
                cmd.Parameters.AddWithValue("@did", appointment.DoctorId);
                cmd.Parameters.AddWithValue("@date", appointment.AppointmentDate);
                cmd.Parameters.AddWithValue("@desc", appointment.Description);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                conn.Close();
                return rows > 0;
            }
        }

        public bool UpdateAppointment(Appointment appointment)
        {
            using (SqlConnection conn = DBConnection.GetConnection())
            {
                string query = "UPDATE Appointment SET patientId=@pid, doctorId=@did, appointmentDate=@date, description=@desc WHERE appointmentId=@aid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@aid", appointment.AppointmentId);
                cmd.Parameters.AddWithValue("@pid", appointment.PatientId);
                cmd.Parameters.AddWithValue("@did", appointment.DoctorId);
                cmd.Parameters.AddWithValue("@date", appointment.AppointmentDate);
                cmd.Parameters.AddWithValue("@desc", appointment.Description);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                conn.Close();
                return rows > 0;
            }
        }

        public bool CancelAppointment(int appointmentId)
        {
            string query = "DELETE FROM Appointment WHERE appointmentId = @id";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", appointmentId);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            conn.Close();
            return rows > 0;
        }
    }


    internal class HospitalImpl
    {
    }
}
