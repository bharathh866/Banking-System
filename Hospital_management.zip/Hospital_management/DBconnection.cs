﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_management.dbconnect
{
    public class DBConnection
    {
        
        
            public static SqlConnection GetConnection()
            {
                string connectionString = "Server=BHARATH_S\\MSSQLSERVER08;Initial Catalog=hospital;Integrated Security=True";
                return new SqlConnection(connectionString);
            }
        }
            internal class DBconnection
        {
        }
    
}