﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hospital_management.classes;
using Hospital_management.excep;
using Hospital_management.interfacedef;
using Hospital_management.interfaceimpl;
using Hospital_management.patient;

namespace Hospital_management
{
    internal class Program
    {
        static void Main(string[] args)
        {
          
                IHospitalService service = new HospitalServiceImpl();

                while (true)
                {
                    Console.WriteLine("=== Hospital Appointment System ===");
                    Console.WriteLine("1.schedule Appointment");
                    Console.WriteLine("2.get Appointment by ID");
                    Console.WriteLine("3.get Appointments for Patient");
                    Console.WriteLine("4.get Appointments for Doctor");
                    Console.WriteLine("5.update Appointment");
                    Console.WriteLine("6.cancel Appointment");
                    Console.WriteLine("7.Add Patient");
                    Console.WriteLine("Add Doctor");
                    Console.WriteLine("0.exit");
                    Console.Write("Choose an option: ");
                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":

                        ScheduleAppointment(service);
                            break;
                        case "2":
                            Console.Write("Enter Appointment ID: ");
                            int aId = int.Parse(Console.ReadLine());
                            var appt = service.GetAppointmentById(aId);
                            Console.WriteLine(appt != null ? appt.ToString() : "Appointment not found.");
                            break;
                        case "3":
                        try
                        {
                            Console.Write("Enter Patient ID: ");
                            int pid = int.Parse(Console.ReadLine());
                            var patientAppts = service.GetAppointmentsForPatient(pid);
                            patientAppts.ForEach(Console.WriteLine);
                        }
                        catch(PatientNumberNotFoundException ex)
                        {
                            Console.Write($"Error Occured { ex.Message}");
                        }
                            break;
                        case "4":
                            Console.Write("Enter Doctor ID:");
                            int did = int.Parse(Console.ReadLine());
                            var doctorAppts = service.GetAppointmentsForDoctor(did);
                            doctorAppts.ForEach(Console.WriteLine);
                            break;
                        case "5":
                              ScheduleAppointment(service, true);
                            break;
                        case "6":
                            Console.Write("Enter Appointment ID to Cancel: ");
                            int cancelId = int.Parse(Console.ReadLine());
                            Console.WriteLine(service.CancelAppointment(cancelId) ? "Cancelled successfully." : "Cancellation failed.");
                            break;

                         case "7":
                          addPatient.RegisterPatient();
                              break;

                       case "8":
                          Doctorhelper.AddDoctor(); 
                        break;
                        case "0":
                            return;
                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                }
            Console.ReadLine();

        }
        static void ScheduleAppointment(IHospitalService service, bool isUpdate = false)
        {
            Console.Write("Appointment ID: ");
            int appointmentId = int.Parse(Console.ReadLine());

            Console.Write("Patient ID: ");
            int patientId = int.Parse(Console.ReadLine());

            Console.Write("Doctor ID: ");
            int doctorId = int.Parse(Console.ReadLine());

            Console.Write("Appointment Date (yyyy-MM-dd): ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Description: ");
            string desc = Console.ReadLine();

            Appointment appointment = new Appointment(appointmentId, patientId, doctorId, date, desc);

            bool result = isUpdate ? service.UpdateAppointment(appointment)  : service.ScheduleAppointment(appointment);

            Console.WriteLine(result ? "Appointment saved successfully." : "Operation failed.");
        }
    }
}
