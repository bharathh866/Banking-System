﻿using System;
using System.Runtime.Serialization;

namespace Hospital_management.excep
{
   
    public  class PatientNumberNotFoundException : Exception
    {
    
        public PatientNumberNotFoundException(string message) : base(message)
        {
        }


       
    }
}